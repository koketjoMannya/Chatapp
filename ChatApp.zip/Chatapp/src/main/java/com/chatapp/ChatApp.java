package com.chatapp;

import java.util.Scanner;

public class ChatApp {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Login login = new Login();

        System.out.println("========================================");
        System.out.println("     WELCOME TO THE CHAT APP");
        System.out.println("========================================");

        // ==================== REGISTRATION ====================
        System.out.println("\n--- REGISTRATION ---");
        System.out.print("Enter your first name: ");
        String firstName = scanner.nextLine().trim();
        System.out.print("Enter your last name: ");
        String lastName = scanner.nextLine().trim();
        System.out.print("Enter a username (must contain '_' and be <=5 chars): ");
        String username = scanner.nextLine().trim();
        System.out.print("Enter a password (>=8 chars, 1 capital, 1 number, 1 special): ");
        String password = scanner.nextLine().trim();
        System.out.print("Enter your SA cell number (e.g., +27838968976): ");
        String cellPhone = scanner.nextLine().trim();

        String registrationResult = login.registerUser(firstName, lastName, username, password, cellPhone);
        System.out.println("\n--- REGISTRATION RESULT ---");
        System.out.println(registrationResult);

        if (login.getStoredUsername() == null) {
            System.out.println("\nRegistration failed. Exiting.");
            scanner.close();
            return;
        }

        // ==================== LOGIN ====================
        System.out.println("\n--- LOGIN ---");
        System.out.print("Enter your username: ");
        String loginUsername = scanner.nextLine().trim();
        System.out.print("Enter your password: ");
        String loginPassword = scanner.nextLine().trim();

        String loginStatus = login.returnLoginStatus(loginUsername, loginPassword);
        System.out.println("\n--- LOGIN RESULT ---");
        System.out.println(loginStatus);

        if (!login.loginUser(loginUsername, loginPassword)) {
            System.out.println("Login failed. Exiting.");
            scanner.close();
            return;
        }

        // ==================== PART 2: MESSAGING ====================
        System.out.println("\nWelcome to QuickChat.");
        
        System.out.print("\nHow many messages do you wish to enter? ");
        int numMessages = Integer.parseInt(scanner.nextLine().trim());
        
        Message[] messages = new Message[numMessages];
        int messagesEntered = 0;
        boolean quit = false;

        while (!quit) {
            System.out.println("\n--- MENU ---");
            System.out.println("Option 1) Send Messages");
            System.out.println("Option 2) Show recently sent messages");
            System.out.println("Option 3) Quit");
            System.out.print("Choose an option: ");
            String choice = scanner.nextLine().trim();

            if (choice.equals("1")) {
                if (messagesEntered >= numMessages) {
                    System.out.println("You have already entered the maximum number of messages.");
                    continue;
                }

                System.out.println("\n--- SENDING MESSAGE " + (messagesEntered + 1) + " ---");
                Message msg = new Message();
                msg.setMessageNumber(messagesEntered + 1);

                System.out.print("Enter recipient cell number (e.g., +27718693002): ");
                String recipient = scanner.nextLine().trim();
                msg.setRecipient(recipient);
                System.out.println(msg.checkRecipientCell());

                System.out.print("Enter message text (max 250 chars): ");
                String text = scanner.nextLine().trim();
                msg.setMessageText(text);

                if (text.length() > 250) {
                    System.out.println("Message exceeds 250 characters by " + (text.length() - 250) + "; please reduce the size.");
                    continue;
                } else {
                    System.out.println("Message ready to send.");
                }

                msg.createMessageHash();
                String actionResult = msg.sentMessage();
                System.out.println(actionResult);

                if (actionResult.equals("Message successfully sent.")) {
                    System.out.println("\n--- MESSAGE DETAILS ---");
                    System.out.println(msg.printMessages());
                    messages[messagesEntered] = msg;
                    messagesEntered++;
                } else if (actionResult.equals("Message successfully stored.")) {
                    System.out.println("\n--- JSON STORED ---");
                    System.out.println(msg.storeMessage());
                    messagesEntered++; 
                }

            } else if (choice.equals("2")) {
                System.out.println("Coming Soon.");
            } else if (choice.equals("3")) {
                System.out.println("Exiting application...");
                if (messagesEntered > 0) {
                    System.out.println("Total messages sent: " + new Message().returnTotalMessages());
                }
                quit = true;
            } else {
                System.out.println("Invalid choice.");
            }
        }

        scanner.close();
    }
}