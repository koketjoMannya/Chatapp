package com.chatapp;

import java.util.Random;
import java.util.Scanner;

public class Message {
    
    private String messageID;
    private int messageNumber;
    private String recipient;
    private String messageText;
    private String messageHash;
    
    private static int totalMessagesSent = 0;

    public Message() {
        this.messageID = generateMessageID();
        this.messageNumber = 0;
        this.recipient = "";
        this.messageText = "";
        this.messageHash = "";
    }

    // Generates a random 10-digit number as a string
    private String generateMessageID() {
        Random rand = new Random();
        long id = 1000000000L + (long)(rand.nextDouble() * 9000000000L);
        return String.valueOf(id);
    }

    // 1. Ensures message ID is not more than 10 characters
    public boolean checkMessageID() {
        return this.messageID.length() <= 10;
    }

    // 2. Ensures recipient cell is not more than 12 chars and starts with code (+)
    public String checkRecipientCell() {
        if (recipient != null && recipient.length() <= 12 && recipient.startsWith("+")) {
            return "Cell phone number successfully captured.";
        }
        return "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.";
    }

    // 3. Creates the Message Hash
    public String createMessageHash() {
        if (messageText == null || messageText.trim().isEmpty()) return "";
        
        String firstTwoID = messageID.substring(0, 2);
        String[] words = messageText.trim().split("\\s+");
        String firstWord = words[0];
        String lastWord = words[words.length - 1];
        
        firstWord = firstWord.replaceAll("[^a-zA-Z]", "");
        lastWord = lastWord.replaceAll("[^a-zA-Z]", "");

        String hash = firstTwoID + ":" + messageNumber + ":" + firstWord + lastWord;
        this.messageHash = hash.toUpperCase();
        return this.messageHash;
    }

    // 4. Allows user to choose Send, Disregard, or Store
    public String sentMessage() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("\nChoose an option:");
        System.out.println("1) Send Message");
        System.out.println("2) Disregard Message");
        System.out.println("3) Store Message to send later");
        System.out.print("Enter choice (1-3): ");
        
        String choice = scanner.nextLine().trim();

        if (choice.equals("1")) {
            totalMessagesSent++;
            return "Message successfully sent.";
        } else if (choice.equals("2")) {
            return "Press 0 to delete the message.";
        } else if (choice.equals("3")) {
            return "Message successfully stored.";
        } else {
            return "Invalid choice.";
        }
    }

    // 5. Prints the details of the message
    public String printMessages() {
        return "Message ID: " + messageID + "\n" +
               "Message Hash: " + messageHash + "\n" +
               "Recipient: " + recipient + "\n" +
               "Message: " + messageText;
    }

    // 6. Returns total sent
    public int returnTotalMessages() {
        return totalMessagesSent;
    }

    // 7. JSON Store Method
    public String storeMessage() {
        String json = "{\n" +
                "  \"messageID\": \"" + messageID + "\",\n" +
                "  \"recipient\": \"" + recipient + "\",\n" +
                "  \"messageText\": \"" + messageText + "\",\n" +
                "  \"messageHash\": \"" + messageHash + "\"\n" +
                "}";
        return json;
    }

    // --- Getters and Setters ---
    public void setMessageNumber(int messageNumber) { this.messageNumber = messageNumber; }
    public void setRecipient(String recipient) { this.recipient = recipient; }
    public void setMessageText(String messageText) { this.messageText = messageText; }
    public String getRecipient() { return recipient; }
    public String getMessageText() { return messageText; }
    public String getMessageHash() { return messageHash; }
    public String getMessageID() { return messageID; }
}